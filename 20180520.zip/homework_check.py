"""
problem 1-1
"""
for x in range(5):
    print("{:^9}".format("*" * (2 * x + 1)))

"""
problem 1-2
"""
for i in range(5):
    for _ in range(5 - (i + 1)):
        print(" ", end="")
    for _ in range(2 * i + 1):
        print("*", end="")
    print("")

"""
problem 2
"""
import random
random_num = random.randint(1, 100)
trial_cnt = 0

while True:
    user_num = int(input("please insert number:"))
    trial_cnt += 1
    
    if random_num == user_num:
        print("{}번 만에 맞췄습니다.".format(trial_cnt))
        break
    elif user_num > random_num:
        print("user number가 더 높습니다.")
    else:
        print("user number가 더 낮습니다.")





