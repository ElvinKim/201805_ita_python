while True:
    try:
        a = int(input("a: "))
        b = int(input("b: "))
        print("{} / {}  = {}".format(a, b, a / b))
    except ZeroDivisionError as e:
        print("0으로 나눴어")
        print(e)
    except TypeError as e:
        print("type이 맞지 않아요")
        print(e)
