from openpyxl import Workbook
wb = Workbook()

ws = wb.active
ws1 = wb.create_sheet("sheet1")
ws2 = wb.create_sheet("sheet2")

ws.title = "new title"

ws["A1"] = 10
ws1["A1"] = 100
ws.cell(row=2, column=1, value=20)

print(ws['A1'])
print(ws['A1'].value)

for i in range(1, 11):
    for j in range(1, 11):
        ws.cell(row=i, column=j, value=(i-1) * 10 + j)


for col_c in ws["C"]:
    print(col_c.value)

for data in ws["A:C"]:
    for cell in data:
        print(cell.value)
    print("-" * 20)
# wb.save('sample.xlsx')


for row in ws.iter_rows():
    print(row[1].value, row[5].value + 100)




