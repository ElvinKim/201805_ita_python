#import my_statistics
# print(my_statistics.x)
# print(my_statistics.add(10, 20))

# def add(a, b):
#     return "안녕"

# from my_statistics import *
# print(my_statistics.add(10, 20))
# import my_statistics

# print(add(10, 20))
# print(my_statistics.add(10, 20))


print("my_main __name__", __name__)
import my_module





