class Knight:
    def __init__(self, lv, name, hp):
        self.level = lv
        self.name = name
        self.hp = hp

    def move(self, direction):
        print(direction + "방향으로 이동")

    def attack(self):
        print(self.name + "이 공격")


k = Knight(20, "나야나", 1000)

print("-" * 20)
print(Knight.__dict__)
print(k.__dict__)
k.name = "자다깬 용사"
print(k.__dict__)

k2 = Knight(25, "만년동핵폭탄", 2000)

print(k2.__dict__)


class Wizard:
    def __init__(self, lv, name, hp):
        self.level = lv
        self.name = name
        self.hp = hp

    def move(self, direction):
        print(direction + "방향으로 이동")

    def attack(self):
        print(self.name + "이 공격")

    def magic(self):
        print(self.name + "이 마법")

    def set_level(self, level):
        if level > 999:
            self.level = 999
        else:
            self.level = level

    def get_level(self):
        return self.level

    def set_hp(self, hp):
        self.hp = hp

    def get_hp(self):
        return self.hp


w = Wizard(100, "만년동이은결", 2000)
# w.level = 999999
w.set_level(99999)
print(w.get_level())
print(w.level)


w.level = 101
print(w.level)





