from openpyxl import load_workbook

loaded_wb = load_workbook("sample.xlsx")
ws = loaded_wb.get_sheet_by_name("new title")

print(ws["A1"].value)