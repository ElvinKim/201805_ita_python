def print_module2():
    print("module 2")