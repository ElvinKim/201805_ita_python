import root_package.module1
from root_package.module2 import *

root_package.module1.print_module1()
print_module2()