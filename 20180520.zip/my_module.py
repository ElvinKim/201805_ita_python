def add(a, b):
    return a + b

print("my_module __name__", __name__)

if __name__ == "__main__":
    print(add(100, 20))
    print(add(100, 200))
    print(add(100, 1000))
