def my_average(*args):
    return sum(args) / len(args)

def my_concat(c, *args):
    return c.join(args)

print(my_average(1, 2, 3, 4, 5))
print(my_concat(",", 'abc', 'def', 'ghi', 'jkl'))