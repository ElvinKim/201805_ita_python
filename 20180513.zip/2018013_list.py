print("{:-^20}".format("리스트 관련 함수"))
# append
print("-" * 20)
a = [1, 2, 3, 4]
a.append(5)
print(a)

# sort
print("-" * 20)
a = [2, 1, 4, 5, 7]
a.sort(reverse=True)
print(a)

# reverse
print("-" * 20)
a = ["python", 2, 3, "aaa", 5, 6]
a.reverse()
print(a)

# index
print("-" * 20)
a = [2, 3, 5, 1]
print(a.index(3))

# insert
print("-" * 20)
a = [1, 3, 4, 5]
a.insert(len(a), 2)
print(a)

# remove
print("-" * 20)
a = [1, 2, 3, 4, 1, 2, 3, 4]
a.remove(3)
print(a)

# pop
print("-" * 20)
a = [1, 2, 3, 4, 5]
print(a.pop())
print(a)
print(a.pop(0))
print(a)

# count
print("-" * 20)
a = [1, 2, 3, 4, 5, 1, 2, 3]
print(a.count(1))

# extend
print("-" * 20)
a = [1, 2, 3, 4]
b = [5, 6, 7, 8]
a.extend(b)
print(a)

a = [1, 2, 3, 4]
b = [5, 6, 7, 8]
a += b # a = a + b

print(a)