num1 = float(input("Please input your num1:"))
num2 = float(input("Please input your num2:"))

if num1 > num2:
    print("{}이 {}보다 큽니다.".format(num1, num2))
elif num1 < num2:
    print("{}이 {}보다 큽니다.".format(num2, num1))
else:
    print("같습니다.")
