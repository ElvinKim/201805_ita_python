print("{:-^20}".format("for"))

for x in [1, 2, 3, "python"]:
    print(x)

print("-" * 20)

for n in range(10):
    print(n)

for x in range(5):
    print("Hello")

# break
print("-" * 20)
for x in range(1, 10):
    print(x)

    if x == 5:
        break

# continue
print("-" * 20)
for x in range(1, 21):
    if x % 2 == 0:
        continue
    print(x)
# gugu
for i in range(2, 10):
    for j in range(1, 10):
        print("{} * {} = {}".format(i, j, i * j))
    print("-" * 10)


