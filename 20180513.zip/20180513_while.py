x = 0

while x < 10:
    print(x)
    x += 1  # x = x + 1

# break
print("-" * 20)
x = 3
while True:
    if 3 * x > 56:
        break
    x += 1
print(x)

while 3 * x < 56:
    x += 1
print(x)

a = 0
while a < 10:
    print(a)
    a += 1