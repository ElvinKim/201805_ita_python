lst = [1, 2, 3, 1, 2, 3, 4, 5, 1, 2]

s = set(lst)
lst = list(s)
print(lst)
print(lst[2])

t = tuple(lst)
print(t)