print("{:-^20}".format("IF"))

# if
print("-" * 20)
if 1 < 2:
    print('A')
    print("C")
    if 10 > 20:
        print("D")
    print("E")
print("B")

# if - else
print("-" * 20)
num = 11
if num % 2 == 0:
    print("짝수")
else:
    print("홀수")


# if - elif - else
print("-" * 20)
num = 12

if num % 5 == 0:
    print("5의 배수")
elif num % 2 == 0:
    print("2의 배수")
elif num % 3 == 0:
    print("3의 배수")

a = 90
if 80 < a < 100:
    print("TEST")

# in 조건문
print("-" * 20)
a = "A"
lst = ["A", "B", "C"]

if a not in lst:
    print("Good")

if "python" in "python is good":
    print("Great!")

# 자료형의 참과 거짓
print("-" * 20)
if "python":
    print("Good")

if None:
    print("TEST")

if [1]:
    print("AAA")

if " ":
    print("BBB")







