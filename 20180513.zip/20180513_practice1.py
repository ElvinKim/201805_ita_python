# 1
lst = [21, 42, 23, 14, 5, 66]

# 2
lst.sort()
print(lst)


# 3
max_num = max(lst)	
min_num = min(lst)	

# 4
lst.remove(max_num)
lst.remove(min_num)
print(lst)

