print("{:-^20}".format("딕셔너리"))
my_info = {"name": "sangmook", 
"age": 20, "friends": ["유재석", "이광수"]}

print(my_info["age"])
print(my_info["friends"])

my_info["age"] = 30
my_info["id"] = 100
my_info['friends'].remove("유재석")
del my_info['friends']
print(my_info)

# 딕셔너리 관련 함수
print("-" * 20)
print(my_info)
print(my_info.keys())
print(my_info.values())
print(my_info.items())
# my_info.clear()
print(my_info.get("name"))
print(my_info["name"])

print(my_info.get("car"))
print(my_info.get("car", "없어요~"))
print(my_info.get("age", "없어요~"))
# print(my_info["car"])
