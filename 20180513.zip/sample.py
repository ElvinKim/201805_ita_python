print("a", "b", "c", sep=",", end="")
print("a", "b", "c", sep=",")
