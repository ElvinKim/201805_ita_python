print("{:=^20}".format("튜플"))


t = (1, 2, 3, 4, 5)
print(t[0])


x, y, z = (1, 2, 5)
print(y)
print(z)

x, y = (y, x)
print(x, "\n", y)
