a = 12345
b = 67890

print("a + b =", a + b)
print("a - b =", a - b)
print("a * b =", a * b)
print("a / b =", a / b)

print(b % a)
print(a ** 2)

money = 20000
print(money * 1133)


