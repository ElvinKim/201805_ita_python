# list
lst = [1, 2, 3, 4, 5]
print(lst[0])
print(lst[0:1])

lst2 = [6, 7, 8, 9, 0]
print(lst + lst2)
print(lst * 3)

print("-" * 20)

a = [1, 2, 3, 4, 5]
a[2:3] = [300]
a[0] = 100
a[-1] = 700
a[1:4] = [200, 300, 400, 500, 600]
print(a)

print("-" * 20)

a = [1, 2, 3, 4, 5]
del a[2]
a[0:2] = []

import copy

a = [1, 2, 3, 4, 5]
b = copy.copy(a)

del b[0]

print(b)
print(a)

print(3e2)