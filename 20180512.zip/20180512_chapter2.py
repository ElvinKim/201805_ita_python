# 변수
a = 100
print(a)
A = 200
print(a)


# 숫자형 자료형
print(4e2)

# 숫자형 자료형 연산자
print(10 ** 3)


# 문자열
a = "python is good"
b = 'python is good'
c = '''python is good'''
d = """python is good"""

print('I\'m a python programmer')
print('''python is good\nI'm a programmer ''')


print("-" * 20)
# 문자열 연산자
print("abc" + "def")

print("-" * 20)

# 인덱싱
print('-' * 20)
a = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'
print(a[1])
print(a[-1])

# 문자열 포매팅
print("-" * 20)
name_format = "저의 이름은 %s 입니다."
age_format = "저의 나이는 %d살 입니다."
my_info_format = "저의 이름은 %s이고 나이는 %d입니다."
my_info_format_v2 = "저의 이름은 %s이고 나이는 %s입니다."


age = 20
print(name_format % "김상묵")
print(age_format % 20)
print(my_info_format % ("김상묵", 20))

print(my_info_format_v2 % ("김상묵", str(age)))

# 문자열 관련 함수
print("-" * 20)
print("ABCDEFGABCAA".count("AB"))

a = "ABCDEFGABC"
print(a.find("C"))
print(a.index("C"))

print(a.find("Z"))

print(",".join(["ABC", "DEF", "GHI"]))

print("PyThon".upper())
print("PyThon".lower())


print("aaaaa      abc      aaaaa".lstrip("a"))
print("      abc      ".rstrip())
print("      abc      ".strip())

a = "   Python is good   "
a = a.strip().replace("good", "great!").replace("Python", "JAVA")

print(a)

print("ABC DEF GHI".split())
print("ABC.DEF.GHI".split("."))


# Format function
print("-" * 20)
name_format = "나의 이름은 {}입니다."
age_format = "나의 나이는 {}살입니다."
my_info_format = "저의 이름은 {}이고 나이는 {}입니다."
my_info_format_v2 = "저의 이름은 {1}이고 나이는 {0}입니다."

print(name_format)
print(name_format.format("김상묵"))
print(age_format.format(20))
print(my_info_format.format("상묵", 20))

print(my_info_format_v2.format("영희", 20))
print(my_info_format_v2.format(20, "영희"))

