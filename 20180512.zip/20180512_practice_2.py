a = 20180125

print(int(a / 10000))
print(int((a % 10000) / 100))

