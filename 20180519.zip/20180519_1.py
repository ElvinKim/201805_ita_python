# 제어문 level up

# list copmression
lst = []
for n in range(1, 11):
	lst.append(n ** 2)
print(lst)

print([x ** 2 for x in range(1, 11)])

# list zip
a = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
b = [x for x in "abcdefg"]

print(a)
print(b)

for x, y in zip(a, b):
	print(x)
	print(y)
	print("-" * 10)

# enumerate
for x in enumerate(b):
	print(x)

for _ in range(10):
	print("hello")



