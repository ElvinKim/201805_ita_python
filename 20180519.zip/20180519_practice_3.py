def get_max_min(lst):
    if len(lst) < 2:
        return

    return max(lst), min(lst)

print(get_max_min([1, 2, 3, 4, 5]))
