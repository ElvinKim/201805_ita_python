# problem 1 - 1
for i in range(5):
	print("*" * (i + 1))

# problem 1 - 2
print("-" * 20)

for x in range(5):
	for y in range(x + 1):
		print("*", end="")
	print("")

# problem 2
# sample_str = "ABCABCAABBCCEE"
# match_c = "B"
# index_lst = []
# index = 0

# for c in sample_str:
# 	if c == match_c:
# 		index_lst.append(index)
# 	index += 1

# print(index_lst)

sample_str = "ABCABCAABBCCEE"
match_c = "B"
index_lst = []

for index, c in enumerate(sample_str):
	if c == match_c:
		index_lst.append(index)

print(index_lst)





