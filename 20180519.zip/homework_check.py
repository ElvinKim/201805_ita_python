"""
problem 1
20180123을 숫자 연산자를 이용하여 2018, 01, 23을 출력해 보세요
(힌트) 나머지 구하는 연산자인 %를 이용해 보세요
"""
a = 20180123
year = int(a / 10000)
month = int((a % 10000) / 100)
day = a % 100
print("{:04d}, {:02d}, {:02d}".format(year, month, day))

"""
problem 2
문자열을 입력받으면 첫 번째 알파벳은 그대로 두고 나머지 문자들은 그 갯수
만큼 언더바(_)로 출력해 보세요
(예) apple -> a____
(힌트) len(문자열)을 활용해 보세요
"""
input_str = input("Insert your word:")
print(input_str[0] + "_" * (len(input_str) - 1))

"""
problem 3
문장을 입력 받은 후 처음 단어와 마지막 단어를 출력해 보세요
"""
input_sentence = input("insert your sentence:")
word_lst = input_sentence.split()
print(word_lst[0], word_lst[-1])


"""
problem 4
print(“*”, end="")와 while문을 이용하여 
“**********”를 출력해 보세요
"""
i = 0
while i < 10:
    print("*", end="")
    i += 1
print("")

"""
x^3 > 10000를 만족하는 
가장 작은 x를 while문을 이용하여 찾아보세요
"""
x = 0
while x ** 3 < 10000:
    x += 1

print(x)
print(22 ** 3)
