n = 0


def make_n_10():
    global n
    n = 10


print("before func", n)
make_n_10()
print("after func", n)

