def return_my_name():
    return "영희"


def repeat_my_name(n):
    for _ in range(n):
        print("영희")


print(return_my_name())
print(repeat_my_name(5))

