def add(a, b):
    return a + b


print(add(1, 2))
print(add("A", "B"))
print(add([1], [2]))

def odd_even(num):
    if num % 2 == 0:
        return "짝수"
    else:
        return "홀수"

print(odd_even(10))


def average(a, b):
	return (a + b) / 2

print("-" * 20)
print(average(1, 2))


def list_average(lst):
	total = 0
	cnt = 0

	for num in lst:
		total += num
		cnt += 1
	return total / cnt

def list_average_2(lst):
	return sum(lst) / len(lst)

print(list_average([1, 2, 3, 4, 5]))
print(list_average_2([1, 2, 3, 4, 5]))

print("-" * 20)

def say_my_name():
	return "영희"

print(say_my_name())


def print_name(name):
	print("my name is", name)

print(print_name("영희"))


print("-" * 20)
def say_hi():
	print("hi")

print(say_hi())

# 함수의 매개변수
print("-" * 20)
def my_sum(*args):
	total = 0
	for num in args:
		total += num

	return total

my_sum(1, 2, 3, 4, 5, 6) + 20

def sample(a, b, *args):
	print(a)
	print(b)
	print(args)


sample("python", 1, 2, "my", "name")

# 함수의 반환값
print("-" * 20)
def sum_sub(a, b):
	return a + b
	return a - b

print(sum_sub(10, 6))


# 매개변수 설정
def add(a, b=20):
	return a + b

def print_a_b(a, b):
	print("a:", a)
	print("b:", b)

# print(add(10))
# print(add(10, 50))

print_a_b(b=10, a=20)





