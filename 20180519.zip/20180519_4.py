class Student:
    name = "상묵"
    student_id = 20170000
    major = "KSE"

    def study(self, subject):
        print(subject + "를 공부한다.")

    def take_test(self, test_name):
        print(test_name, "를 친다.")


class ITA_Staff:
    name = "영희"
    position = "과장"

    def lecture(self, subject):
        print(subject + "를 가르치다.")

    def prepare_class(self, subject):
        print(subject + "를 준비하다.")


class Knight:
    level = 20
    name = "만년동핵폭탄"
    hp = 200

    def move(self, direction):
        print(direction + "방향으로 이동")

    def attack(self):
        print("in attack", id(self))
        print(self.name + "이 공격")


k = Knight()
k2 = Knight()
k3 = Knight()

print(k.name)
print(k.hp)
k.attack()
k.move("앞")
print("id of k", id(k))

a = [1, 2, 3]
print(a.sort())

